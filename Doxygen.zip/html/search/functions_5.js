var searchData=
[
  ['makecreature_0',['MakeCreature',['../class_mandatory2_d_game_framework_1_1model_1_1_creatures_1_1_creature_factory.html#a12205d0fb6e1ffd657b17a235d28fb15',1,'Mandatory2DGameFramework::model::Creatures::CreatureFactory']]]
];
