var searchData=
[
  ['range_0',['Range',['../class_mandatory2_d_game_framework_1_1model_1_1attack_1_1_attack_item.html#a993c8584493e0b9219fce3bacca19750',1,'Mandatory2DGameFramework::model::attack::AttackItem']]],
  ['reducehitpoint_1',['ReduceHitPoint',['../class_mandatory2_d_game_framework_1_1model_1_1defence_1_1_defence_item.html#a2df60e0ab8385829c6f7dcc88fd23c45',1,'Mandatory2DGameFramework::model::defence::DefenceItem']]],
  ['removeable_2',['Removeable',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world_object.html#abca7cfd24dc84cd0a7ba83538abfc888',1,'Mandatory2DGameFramework::worlds::WorldObject']]]
];
