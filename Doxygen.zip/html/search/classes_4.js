var searchData=
[
  ['mylogger_0',['MyLogger',['../class_mandatory2_d_game_framework_1_1_my_logger.html',1,'Mandatory2DGameFramework']]]
];
