var searchData=
[
  ['creaturetype_0',['CreatureType',['../namespace_mandatory2_d_game_framework_1_1model_1_1_creatures.html#a3567862a9f2d7fdb741b5a639a58266e',1,'Mandatory2DGameFramework::model::Creatures']]]
];
