var searchData=
[
  ['while_0',['while',['../_program_8cs.html#adb1471bfd380b8cd2f33d69140ce8697',1,'Program.cs']]],
  ['world_1',['World',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world.html#af9eb31a854c51599953a5b19b7780aad',1,'Mandatory2DGameFramework::worlds::World']]],
  ['worldobject_2',['WorldObject',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world_object.html#a36701698b4ac1503dca8f4a57dc7cfc7',1,'Mandatory2DGameFramework::worlds::WorldObject']]],
  ['writeline_3',['WriteLine',['../_program_8cs.html#a6ad22043765a419d630ec2beb7d3faa5',1,'WriteLine(&quot;This is a test environment&quot;):&#160;Program.cs'],['../_program_8cs.html#a8f2b5fdbf995eb3c9cfe0228da12cb92',1,'WriteLine($&quot;{Krigeren.CreatureName} ready for battle with his {Krigeren.AttackItem.Name} doing {Krigeren.AttackItem.Hit} damage and his defence item: {Krigeren.DefenceItem.Name}, shielding him from {Krigeren.DefenceItem.ReduceHitPoint} damage!&quot;):&#160;Program.cs'],['../_program_8cs.html#aefae4e8b63a71477af33ad123059eee7',1,'WriteLine($&quot;{Modstanderen.CreatureName} ready for battle with his {Modstanderen.AttackItem.Name} doing {Modstanderen.AttackItem.Hit} damage and his defence item: {Modstanderen.DefenceItem.Name}, shielding him from {Modstanderen.DefenceItem.ReduceHitPoint} damage!&quot;):&#160;Program.cs']]]
];
