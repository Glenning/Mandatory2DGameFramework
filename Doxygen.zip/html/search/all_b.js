var searchData=
[
  ['program_2ecs_0',['Program.cs',['../_program_8cs.html',1,'']]],
  ['propertychanged_1',['PropertyChanged',['../class_mandatory2_d_game_framework_1_1model_1_1_cretures_1_1_creature.html#a4cc5f20b33b0e88791682d7e6bee48cf',1,'Mandatory2DGameFramework::model::Cretures::Creature']]]
];
