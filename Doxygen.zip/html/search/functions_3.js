var searchData=
[
  ['initialize_0',['Initialize',['../class_mandatory2_d_game_framework_1_1_config_reader.html#a17d8b133b6c5829480fec28da32a92ca',1,'Mandatory2DGameFramework.ConfigReader.Initialize()'],['../_program_8cs.html#ae6c4e96c3b7a47c477fcd267015a77e3',1,'Initialize():&#160;Program.cs']]]
];
