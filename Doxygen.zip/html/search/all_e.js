var searchData=
[
  ['warrior_0',['Warrior',['../namespace_mandatory2_d_game_framework_1_1model_1_1_creatures.html#a3567862a9f2d7fdb741b5a639a58266ea7ee7fa010d64b90a36803a8445f2e943',1,'Mandatory2DGameFramework::model::Creatures']]],
  ['while_1',['while',['../_program_8cs.html#adb1471bfd380b8cd2f33d69140ce8697',1,'Program.cs']]],
  ['world_2',['World',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world.html',1,'Mandatory2DGameFramework.worlds.World'],['../class_mandatory2_d_game_framework_1_1worlds_1_1_world.html#af9eb31a854c51599953a5b19b7780aad',1,'Mandatory2DGameFramework.worlds.World.World()']]],
  ['world_2ecs_3',['World.cs',['../_world_8cs.html',1,'']]],
  ['worldobject_4',['WorldObject',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world_object.html',1,'Mandatory2DGameFramework.worlds.WorldObject'],['../class_mandatory2_d_game_framework_1_1worlds_1_1_world_object.html#a36701698b4ac1503dca8f4a57dc7cfc7',1,'Mandatory2DGameFramework.worlds.WorldObject.WorldObject()']]],
  ['worldobject_2ecs_5',['WorldObject.cs',['../_world_object_8cs.html',1,'']]],
  ['writeline_6',['WriteLine',['../_program_8cs.html#a6ad22043765a419d630ec2beb7d3faa5',1,'WriteLine(&quot;This is a test environment&quot;):&#160;Program.cs'],['../_program_8cs.html#a8f2b5fdbf995eb3c9cfe0228da12cb92',1,'WriteLine($&quot;{Krigeren.CreatureName} ready for battle with his {Krigeren.AttackItem.Name} doing {Krigeren.AttackItem.Hit} damage and his defence item: {Krigeren.DefenceItem.Name}, shielding him from {Krigeren.DefenceItem.ReduceHitPoint} damage!&quot;):&#160;Program.cs'],['../_program_8cs.html#aefae4e8b63a71477af33ad123059eee7',1,'WriteLine($&quot;{Modstanderen.CreatureName} ready for battle with his {Modstanderen.AttackItem.Name} doing {Modstanderen.AttackItem.Hit} damage and his defence item: {Modstanderen.DefenceItem.Name}, shielding him from {Modstanderen.DefenceItem.ReduceHitPoint} damage!&quot;):&#160;Program.cs']]]
];
