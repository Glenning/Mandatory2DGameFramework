var searchData=
[
  ['warrior_0',['Warrior',['../namespace_mandatory2_d_game_framework_1_1model_1_1_creatures.html#a3567862a9f2d7fdb741b5a639a58266ea7ee7fa010d64b90a36803a8445f2e943',1,'Mandatory2DGameFramework::model::Creatures']]]
];
