var searchData=
[
  ['instance_0',['Instance',['../class_mandatory2_d_game_framework_1_1_config_reader.html#ab1baf1acb20b296044b43d5256913777',1,'Mandatory2DGameFramework.ConfigReader.Instance'],['../class_mandatory2_d_game_framework_1_1_my_logger.html#aebf356fca3e3d7d50e6155e0d4070fad',1,'Mandatory2DGameFramework.MyLogger.Instance']]]
];
