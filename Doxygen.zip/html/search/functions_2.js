var searchData=
[
  ['death_0',['Death',['../class_mandatory2_d_game_framework_1_1model_1_1_cretures_1_1_creature.html#a0cb653f009a27de9e1b7ea35993e7743',1,'Mandatory2DGameFramework::model::Cretures::Creature']]],
  ['defenceitem_1',['DefenceItem',['../class_mandatory2_d_game_framework_1_1model_1_1defence_1_1_defence_item.html#a50bd13bce5c0a2fc16f2616b44a4c3a8',1,'Mandatory2DGameFramework::model::defence::DefenceItem']]]
];
