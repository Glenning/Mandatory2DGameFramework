var searchData=
[
  ['creaturename_0',['CreatureName',['../class_mandatory2_d_game_framework_1_1model_1_1_cretures_1_1_creature.html#a8bb6ac49ae5157ae2464c4ad008a6427',1,'Mandatory2DGameFramework::model::Cretures::Creature']]]
];
