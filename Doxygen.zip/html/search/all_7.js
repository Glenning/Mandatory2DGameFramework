var searchData=
[
  ['krigeren_0',['Krigeren',['../_program_8cs.html#aa47b51b11f1f1f9a141474ba7ac44f10',1,'Program.cs']]]
];
