var searchData=
[
  ['beast_0',['Beast',['../namespace_mandatory2_d_game_framework_1_1model_1_1_creatures.html#a3567862a9f2d7fdb741b5a639a58266ea8023727f8bbdfc6efb4944197420bf7e',1,'Mandatory2DGameFramework::model::Creatures']]],
  ['boss_1',['Boss',['../namespace_mandatory2_d_game_framework_1_1model_1_1_creatures.html#a3567862a9f2d7fdb741b5a639a58266ea5859831e2b3db23528c710b1451e13fc',1,'Mandatory2DGameFramework::model::Creatures']]]
];
