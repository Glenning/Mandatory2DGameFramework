var searchData=
[
  ['world_0',['World',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world.html',1,'Mandatory2DGameFramework::worlds']]],
  ['worldobject_1',['WorldObject',['../class_mandatory2_d_game_framework_1_1worlds_1_1_world_object.html',1,'Mandatory2DGameFramework::worlds']]]
];
