var searchData=
[
  ['name_0',['Name',['../class_mandatory2_d_game_framework_1_1model_1_1attack_1_1_attack_item.html#a3427c49ca9147e1cb245bb888f35a53d',1,'Mandatory2DGameFramework.model.attack.AttackItem.Name'],['../class_mandatory2_d_game_framework_1_1model_1_1defence_1_1_defence_item.html#ab51229b56b442bbb9b5d3748ff69b7d8',1,'Mandatory2DGameFramework.model.defence.DefenceItem.Name'],['../class_mandatory2_d_game_framework_1_1worlds_1_1_world_object.html#a22287e4da7ba3627ce0a41cf10dc4a2c',1,'Mandatory2DGameFramework.worlds.WorldObject.Name']]]
];
