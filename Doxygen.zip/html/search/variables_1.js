var searchData=
[
  ['maxx_0',['MaxX',['../class_mandatory2_d_game_framework_1_1_config_reader.html#a85253864b4767c386f594c49fb3d9172',1,'Mandatory2DGameFramework::ConfigReader']]],
  ['modstanderen_1',['Modstanderen',['../_program_8cs.html#a0399da555ebfaa49fecfde03013414cc',1,'Program.cs']]]
];
